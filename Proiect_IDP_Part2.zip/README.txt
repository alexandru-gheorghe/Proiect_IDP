Readme
Gheorghe Alexandru 341C3
Nica Andrei 341C5
Repository : https://github.com/alexandru-gheorghe/Proiect_IDP/ 

Aplicatia se ruleaza cu ant run.

Butonul de login functioneaza in orice conditii

Pentru a rula simularea pentru Consumator se inlocuieste fisierul config.txt cu consumator.txt.
Pentru a  vedea rezultatele simularii ar trebui ca cateva servicii sa fie activate cu Launch Request

Pentru a rula simularea pentru Producator se inlocuieste fisierul config.txt cu produc.txt.


Merge!
Merge 2
